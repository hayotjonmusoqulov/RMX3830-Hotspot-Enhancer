package com.rmx3830.hotspot;

import android.os.Build;
import android.util.Log;

import java.lang.reflect.Method;

import io.github.libxposed.api.XposedInterface;
import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface;

/**
 * RMX3830 Hotspot Enhancer v0.3.1
 *
 * Diagnostic-first Modern Xposed API 102 module.
 * It does not change hotspot configuration yet. It discovers and logs the
 * SoftApConfiguration / SoftApManager / Settings methods that are available
 * on this particular Realme Android 15 build.
 */
public final class HotspotModule extends XposedModule {
    private static final String TAG = "RMX3830Hotspot";
    private static final String[] FRAMEWORK_CLASSES = {
            "android.net.wifi.SoftApConfiguration",
            "android.net.wifi.SoftApConfiguration$Builder",
            "com.android.server.wifi.SoftApManager"
    };

    private static final String[] SETTINGS_CLASSES = {
            "com.android.settings.TetherSettings",
            "com.android.settings.wifi.tether.WifiTetherSettings",
            "com.android.settings.network.TetherSettings"
    };

    private static final XposedInterface.Hooker LOG_HOOKER = chain -> {
        try {
            String method = chain.getExecutable().getName();
            Object[] args = chain.getArgs().toArray();
            log("CALL " + method + " args=" + safeArgs(args));
            Object result = chain.proceed();
            log("RET " + method + " => " + safeValue(result));
            return result;
        } catch (Throwable t) {
            log("HOOK_EXCEPTION " + t);
            throw t;
        }
    };

    @Override
    public void onModuleLoaded(XposedModuleInterface.ModuleLoadedParam param) {
        log("loaded api=" + getApiVersion()
                + " process=" + param.getProcessName()
                + " systemServer=" + param.isSystemServer()
                + " sdk=" + Build.VERSION.SDK_INT);
    }

    @Override
    public void onSystemServerStarting(XposedModuleInterface.SystemServerStartingParam param) {
        log("system_server starting; classLoader=" + param.getClassLoader());
        for (String className : FRAMEWORK_CLASSES) {
            probeAndHook(param.getClassLoader(), className);
        }
    }

    @Override
    public void onPackageReady(XposedModuleInterface.PackageReadyParam param) {
        if (!"com.android.settings".equals(param.getPackageName())) return;
        log("Settings ready process=" + param.getProcessName());
        for (String className : SETTINGS_CLASSES) {
            probeSettings(param.getClassLoader(), className);
        }
    }

    private void probeAndHook(ClassLoader loader, String className) {
        try {
            Class<?> clazz = Class.forName(className, false, loader);
            log("FOUND " + className);
            int hooked = 0;
            for (Method method : clazz.getDeclaredMethods()) {
                if (!interesting(method.getName())) continue;
                log("METHOD " + method.toGenericString());
                try {
                    hook(method).intercept(LOG_HOOKER);
                    hooked++;
                } catch (Throwable t) {
                    log("HOOK_FAIL " + method.toGenericString() + " :: " + t);
                }
            }
            log("HOOKED " + className + " count=" + hooked);
        } catch (Throwable t) {
            log("MISS " + className + " :: " + t);
        }
    }

    private void probeSettings(ClassLoader loader, String className) {
        try {
            Class<?> clazz = Class.forName(className, false, loader);
            log("SETTINGS_FOUND " + className);
            for (Method method : clazz.getDeclaredMethods()) {
                if (interesting(method.getName())) {
                    log("SETTINGS_METHOD " + method.toGenericString());
                }
            }
        } catch (Throwable t) {
            log("SETTINGS_MISS " + className + " :: " + t);
        }
    }

    private static boolean interesting(String name) {
        String n = name.toLowerCase();
        return n.contains("client") || n.contains("shutdown") || n.contains("channel")
                || n.contains("band") || n.contains("hidden") || n.contains("isolation")
                || n.contains("configuration") || n.contains("softap")
                || n.contains("ssid") || n.contains("passphrase")
                || n.contains("timeout") || n.contains("allowed") || n.contains("blocked");
    }

    private static String safeArgs(Object[] args) {
        if (args == null) return "null";
        StringBuilder out = new StringBuilder("[");
        for (int i = 0; i < args.length; i++) {
            if (i != 0) out.append(", ");
            out.append(safeValue(args[i]));
        }
        return out.append(']').toString();
    }

    private static String safeValue(Object value) {
        if (value == null) return "null";
        String type = value.getClass().getName().toLowerCase();
        if (type.contains("passphrase") || type.contains("password")) return "<redacted>";
        String s = String.valueOf(value);
        if (s.length() > 500) s = s.substring(0, 500) + "…";
        return s;
    }

    private static void log(String message) {
        Log.i(TAG, message);
    }
}
